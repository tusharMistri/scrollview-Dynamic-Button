//
//  ViewController.swift
//  DynamicButton+ScrollView
//
//  Created by Tushar on 16/06/18.
//  Copyright © 2018 tushar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let SPACE_ = 5
    var WIDTH = Int(UIScreen.main.bounds.width / 2)
    let HEIGHT = 100
    var XPOS = 5
    var YPOS = 5
    var COUNTER = 0
    var ROWSPACE = 0
    var requiredNOSEQ = 0
    
    @IBOutlet var objscrollview: UIScrollView!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        requiredNOSEQ = 8
        ROWSPACE = requiredNOSEQ + 1
        WIDTH = (Int(UIScreen.main.bounds.width) / requiredNOSEQ)
        self.createButton(noOfButtons: 15)
    }

    func createButton(noOfButtons:Int)
    {
        for i in 0..<noOfButtons
        {
            let btn = UIButton.init(frame: CGRect(x: XPOS, y: YPOS, width: WIDTH - (SPACE_ + 3), height: HEIGHT))
            btn.backgroundColor = .red
            objscrollview.addSubview(btn)
            XPOS = XPOS + WIDTH
            //if i % 2 != 0
            if COUNTER == requiredNOSEQ
            {
                COUNTER = 0
                XPOS = 5
                YPOS = YPOS + SPACE_ + Int(btn.frame.size.height)
            }
            COUNTER = COUNTER + 1
            if i + 1 == noOfButtons
            {
                objscrollview.contentSize = CGSize(width: UIScreen.main.bounds.width, height:btn.frame.origin.y + CGFloat(HEIGHT)  + CGFloat(SPACE_))
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    
    }


}

